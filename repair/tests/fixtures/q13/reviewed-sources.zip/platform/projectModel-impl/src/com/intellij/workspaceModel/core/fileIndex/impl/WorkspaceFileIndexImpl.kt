// Copyright 2000-2026 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.workspaceModel.core.fileIndex.impl

import com.intellij.injected.editor.VirtualFileWindow
import com.intellij.notebook.editor.BackedVirtualFile
import com.intellij.openapi.Disposable
import com.intellij.openapi.application.runReadActionBlocking
import com.intellij.openapi.diagnostic.ThrottledLogger
import com.intellij.openapi.diagnostic.thisLogger
import com.intellij.openapi.extensions.ExtensionPointName
import com.intellij.openapi.project.Project
import com.intellij.openapi.roots.ContentIteratorEx
import com.intellij.openapi.roots.impl.DirectoryIndexImpl
import com.intellij.openapi.util.Disposer
import com.intellij.openapi.util.LowMemoryWatcher
import com.intellij.openapi.vfs.VfsUtilCore
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.openapi.vfs.VirtualFileFilter
import com.intellij.openapi.vfs.VirtualFileManager
import com.intellij.openapi.vfs.VirtualFileVisitor
import com.intellij.openapi.vfs.newvfs.BulkFileListener
import com.intellij.openapi.vfs.newvfs.CacheAvoidingVirtualFile
import com.intellij.openapi.vfs.newvfs.NewVirtualFile
import com.intellij.openapi.vfs.newvfs.events.VFileEvent
import com.intellij.platform.backend.workspace.WorkspaceModel
import com.intellij.platform.backend.workspace.virtualFile
import com.intellij.platform.backend.workspace.workspaceModel
import com.intellij.platform.workspace.storage.WorkspaceEntity
import com.intellij.platform.workspace.storage.impl.url.VirtualFileUrlManagerImpl
import com.intellij.psi.search.GlobalSearchScope
import com.intellij.serviceContainer.NonInjectable
import com.intellij.util.PathUtil
import com.intellij.util.Query
import com.intellij.util.ThreeState
import com.intellij.util.concurrency.annotations.RequiresReadLock
import com.intellij.util.containers.TreeNodeProcessingResult
import com.intellij.workspaceModel.core.fileIndex.EntityStorageKind
import com.intellij.workspaceModel.core.fileIndex.WorkspaceFileIndexContributor
import com.intellij.workspaceModel.core.fileIndex.WorkspaceFileSet
import com.intellij.workspaceModel.core.fileIndex.WorkspaceFileSetData
import com.intellij.workspaceModel.core.fileIndex.WorkspaceFileSetWithCustomData
import com.intellij.workspaceModel.core.fileIndex.impl.WorkspaceFileInternalInfo.NonWorkspace
import kotlinx.coroutines.CoroutineScope
import org.jetbrains.annotations.ApiStatus
import java.util.concurrent.TimeUnit.MINUTES
import java.util.concurrent.atomic.AtomicReference

class WorkspaceFileIndexImpl : WorkspaceFileIndexEx, Disposable.Default {
  companion object {
    @JvmField
    val EP_NAME: ExtensionPointName<WorkspaceFileIndexContributor<*>> =
      ExtensionPointName("com.intellij.workspaceModel.fileIndexContributor")

    /**
     * Retrieves the [WorkspaceFileSetWithCustomData] corresponding to the given [WorkspaceFileInternalInfo].
     */
    @ApiStatus.Internal
    fun <D : WorkspaceFileSetData> fileSetWithCustomDataByWorkspaceInfo(
      info: WorkspaceFileInternalInfo,
      customDataClass: Class<out D>,
    ): WorkspaceFileSetWithCustomData<D>? {
      val result = when (info) {
        is WorkspaceFileSetWithCustomData<*> -> info.takeIf { customDataClass.isInstance(it.data) }
        is MultipleWorkspaceFileSets -> info.find(customDataClass)
        else -> null
      }
      @Suppress("UNCHECKED_CAST")
      return result as? WorkspaceFileSetWithCustomData<D>
    }
  }

  private val project: Project
  private val indexDataReference: AtomicReference<WorkspaceFileIndexData> =
    AtomicReference<WorkspaceFileIndexData>(EmptyWorkspaceFileIndexData.NOT_INITIALIZED)
  private val throttledLogger: ThrottledLogger = ThrottledLogger(thisLogger(), MINUTES.toMillis(1))

  constructor(project: Project, coroutineScope: CoroutineScope) {
    this.project = project
    project.messageBus.simpleConnect().subscribe(VirtualFileManager.VFS_CHANGES, object : BulkFileListener {
      override fun after(events: List<VFileEvent>) {
        if (DirectoryIndexImpl.shouldResetOnEvents(events)) {
          indexData.clearPackageDirectoryCache()
          if (events.any(DirectoryIndexImpl::isIgnoredFileCreated)) {
            indexData.resetFileCache()
          }
        }
      }
    })
    LowMemoryWatcher.register({ indexData.onLowMemory() }, project)
    EP_NAME.addChangeListener(coroutineScope) { indexData = EmptyWorkspaceFileIndexData.RESET }
  }

  @NonInjectable
  constructor(project: Project, indexData: WorkspaceFileIndexData) {
    this.project = project
    indexDataReference.set(indexData)
  }

  override var indexData: WorkspaceFileIndexData
    get() = indexDataReference.get()
    set(newValue) {
      fun WorkspaceFileIndexData.dispose() {
        if (this is Disposable) Disposer.dispose(this)
      }

      val current = indexDataReference.get()
      if (indexDataReference.compareAndSet(current, newValue)) {
        current.dispose()
      }
      else {
        newValue.dispose()
      }
    }

  override fun isInWorkspace(file: VirtualFile): Boolean = findFileSet(
    file, honorExclusion = true, includeContentSets = true, includeContentNonIndexableSets = true, includeExternalSets = true,
    includeExternalSourceSets = true, includeExternalNonIndexableSets = true, includeCustomKindSets = true
  ) != null

  override fun isInContent(file: VirtualFile): Boolean = findFileSet(
    file, honorExclusion = true, includeContentSets = true, includeContentNonIndexableSets = true, includeExternalSets = false,
    includeExternalSourceSets = false, includeExternalNonIndexableSets = false, includeCustomKindSets = false
  ) != null

  override fun isIndexable(file: VirtualFile): Boolean = findFileSet(
    file, honorExclusion = true, includeContentSets = true, includeContentNonIndexableSets = false, includeExternalSets = true,
    includeExternalSourceSets = true, includeExternalNonIndexableSets = false, includeCustomKindSets = true
  ) != null

  override fun getContentFileSetRoot(file: VirtualFile, honorExclusion: Boolean): VirtualFile? = findFileSet(
    file, honorExclusion, includeContentSets = true, includeContentNonIndexableSets = true, includeExternalSets = false,
    includeExternalSourceSets = false, includeExternalNonIndexableSets = false, includeCustomKindSets = false
  )?.root

  override fun isUrlInContent(url: String): ThreeState {
    var currentUrl = url
    var includeNonRecursive = true
    val fileManager = VirtualFileManager.getInstance()
    val urlManager = WorkspaceModel.getInstance(project).getVirtualFileUrlManager()
    while (currentUrl.isNotEmpty()) {
      val file = fileManager.findFileByUrl(currentUrl)
      if (file != null) {
        return ThreeState.fromBoolean(isInContent(file))
      }
      val virtualFileUrl = urlManager.findByUrl(currentUrl)
      if (virtualFileUrl != null) {
        val kinds = getMainIndexData().getNonExistentFileSetKinds(virtualFileUrl, includeNonRecursive)
        if (NonExistingFileSetKind.EXCLUDED_FROM_CONTENT in kinds) {
          return ThreeState.NO
        }
        if (NonExistingFileSetKind.EXCLUDED_OTHER in kinds) {
          return ThreeState.UNSURE
        }
        if (NonExistingFileSetKind.INCLUDED_CONTENT in kinds) {
          return ThreeState.YES
        }
        if (NonExistingFileSetKind.INCLUDED_CONTENT_NON_INDEXABLE in kinds) {
          return ThreeState.YES
        }
      }
      currentUrl = PathUtil.getParentPath(currentUrl)
      includeNonRecursive = false
    }
    return ThreeState.NO
  }

  override fun isUrlIndexableRecursiveFileSetRoot(url: String): Boolean {
    val virtualFileUrl = project.workspaceModel.getVirtualFileUrlManager().findByUrl(url)
    // MAYBE IM: do early return if virtualFileUrl == null, when all filesets must be registered by VirtualFileUrl

    if (virtualFileUrl != null) {
      val kinds = getMainIndexData().getNonExistentFileSetKinds(virtualFileUrl, false)
      when {
        NonExistingFileSetKind.EXCLUDED_FROM_CONTENT in kinds -> return false
        NonExistingFileSetKind.EXCLUDED_OTHER in kinds -> return false
        NonExistingFileSetKind.INCLUDED_CONTENT in kinds -> return true
        NonExistingFileSetKind.INCLUDED_OTHER in kinds -> return true
        NonExistingFileSetKind.INCLUDED_CONTENT_NON_INDEXABLE in kinds -> return false
      }
    }

    val file = VirtualFileManager.getInstance().findFileByUrlWithoutCaching(url)
    // filesets can not be registered on cache-avoiding files
    if (file != null && file !is CacheAvoidingVirtualFile) {
      val fileSets = findFileSets(file, true, true, false, true, true, false, true)
      if (fileSets.any { (it as? WorkspaceFileSetWithCustomData<*>)?.recursive == true && it.root == file }) {
        return true
      }
    }

    return false
  }

  override fun processContentUnderDirectory(
    fileOrDir: VirtualFile,
    processor: ContentIteratorEx,
    customFilter: VirtualFileFilter?,
    fileSetFilter: (WorkspaceFileSetWithCustomData<*>) -> Boolean,
  ): Boolean {
    return processContentUnderDirectory(fileOrDir, processor, customFilter, fileSetFilter, 0)
  }

  private fun processContentUnderDirectory(
    fileOrDir: VirtualFile,
    processor: ContentIteratorEx,
    customFilter: VirtualFileFilter?,
    fileSetFilter: (WorkspaceFileSetWithCustomData<*>) -> Boolean,
    numberOfExcludedParentDirectories: Int,
  ): Boolean {
    val visitor = object : VirtualFileVisitor<Void?>() {
      override fun visitFileEx(file: VirtualFile): Result {
        val fileInfo = getFileInfo(
          file, honorExclusion = true, includeContentSets = true, includeContentNonIndexableSets = true, includeExternalSets = false,
          includeExternalSourceSets = false, includeExternalNonIndexableSets = false, includeCustomKindSets = false
        )

        if (file.isDirectory && fileInfo is NonWorkspace) {
          return when (fileInfo) {
            NonWorkspace.EXCLUDED, NonWorkspace.NOT_UNDER_ROOTS -> {
              processContentFilesUnderExcludedDirectory(
                file, processor, customFilter, fileSetFilter, fileOrDir, numberOfExcludedParentDirectories
              )
            }
            NonWorkspace.IGNORED, NonWorkspace.INVALID -> {
              SKIP_CHILDREN
            }
          }
        }
        val accepted = runReadActionBlocking {
          fileInfo.findFileSet(fileSetFilter) != null && (customFilter == null || customFilter.accept(file))
        }
        val status = if (accepted) processor.processFileEx(file) else TreeNodeProcessingResult.CONTINUE
        return when (status) {
          TreeNodeProcessingResult.CONTINUE -> CONTINUE
          TreeNodeProcessingResult.SKIP_CHILDREN -> SKIP_CHILDREN
          TreeNodeProcessingResult.SKIP_TO_PARENT -> skipTo(file.parent)
          TreeNodeProcessingResult.STOP -> skipTo(fileOrDir)
        }
      }
    }
    // wrap non-indexable files as CacheAvoiding to prevent them from loading into VFS
    val isIndexable = isIndexable(fileOrDir)
    val cacheAvoidingIfNecessary = when {
      isIndexable -> fileOrDir
      else -> NewVirtualFile.asCacheAvoiding(fileOrDir)
    }
    val result = VfsUtilCore.visitChildrenRecursively(cacheAvoidingIfNecessary, visitor)
    return result.skipToParent != cacheAvoidingIfNecessary
  }

  private fun processContentFilesUnderExcludedDirectory(
    dir: VirtualFile,
    processor: ContentIteratorEx,
    customFilter: VirtualFileFilter?,
    fileSetFilter: (WorkspaceFileSetWithCustomData<*>) -> Boolean,
    rootDir: VirtualFile,
    numberOfExcludedParentDirectories: Int,
  ): VirtualFileVisitor.Result {
    if (numberOfExcludedParentDirectories > 5) {
      /*
         It seems improbable that there are more than 5 alternations between excluded and non-excluded directories, so it seems that this
         is an infinite recursion.
         However, check should catch such cases in VirtualFileVisitor.allowVisitChildren, so report the details and skip processing.
      */
      reportInfiniteRecursion(dir, this)
      return VirtualFileVisitor.SKIP_CHILDREN
    }

    /* there may be other file sets under this directory; their URLs must be registered in VirtualFileUrlManager,
       so it's enough to process VirtualFileUrls only. */
    val virtualFileUrlManager = WorkspaceModel.getInstance(project).getVirtualFileUrlManager() as VirtualFileUrlManagerImpl
    val processed = virtualFileUrlManager.processChildrenRecursively(dir.url) { childUrl ->
      val childFile = childUrl.virtualFile ?: return@processChildrenRecursively TreeNodeProcessingResult.SKIP_CHILDREN
      val isChildInContent = findFileSet(
        childFile, honorExclusion = true, includeContentSets = true, includeContentNonIndexableSets = true, includeExternalSets = false,
        includeExternalSourceSets = false, includeExternalNonIndexableSets = false, includeCustomKindSets = false
      ) != null
      return@processChildrenRecursively if (isChildInContent) {
        if (processContentUnderDirectory(childFile, processor, customFilter, fileSetFilter, numberOfExcludedParentDirectories + 1)) {
          TreeNodeProcessingResult.SKIP_CHILDREN
        }
        else {
          TreeNodeProcessingResult.STOP
        }
      }
      else {
        TreeNodeProcessingResult.CONTINUE
      }
    }
    return if (!processed) {
      VirtualFileVisitor.skipTo(rootDir)
    }
    else VirtualFileVisitor.SKIP_CHILDREN
  }

  override fun findFileSet(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
  ): WorkspaceFileSet? {
    val info = getFileInfo(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
    return when (info) {
      is WorkspaceFileSetImpl -> info
      is MultipleWorkspaceFileSets -> info.find(null)
      else -> null
    }
  }

  override fun findFileSets(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
  ): List<WorkspaceFileSet> {
    val info = getFileInfo(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
    return when (info) {
      is WorkspaceFileSetImpl -> listOf(info)
      is MultipleWorkspaceFileSets -> info.fileSets
      else -> emptyList()
    }
  }

  override suspend fun initialize() {
    if (indexData is EmptyWorkspaceFileIndexData) {
      val contributors = EP_NAME.extensionList
      indexData = initWorkspaceFileIndexData(
        contributorList = contributors,
        project = project,
      )
    }
  }

  override fun initializeBlocking() {
    if (indexData is EmptyWorkspaceFileIndexData) {
      indexData = doInitializeBlocking()
    }
  }

  private fun doInitializeBlocking(): WorkspaceFileIndexDataImpl =
    blockingInitWorkspaceFileIndexData(project, contributorList = EP_NAME.extensionList)

  override fun <D : WorkspaceFileSetData> findFileSetWithCustomData(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
    customDataClass: Class<out D>,
  ): WorkspaceFileSetWithCustomData<D>? {
    val info = getFileInfo(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )

    return fileSetWithCustomDataByWorkspaceInfo(info, customDataClass)
  }

  override fun <D : WorkspaceFileSetData> findFileSetsWithCustomData(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
    customDataClass: Class<out D>,
  ): List<WorkspaceFileSetWithCustomData<D>> {
    val info = getFileInfo(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
    val result = when (info) {
      is WorkspaceFileSetWithCustomData<*> -> listOfNotNull(info.takeIf { customDataClass.isInstance(it.data) })
      is MultipleWorkspaceFileSets -> info.fileSets.filter { customDataClass.isInstance(it.data) }
      else -> emptyList()
    }
    @Suppress("UNCHECKED_CAST")
    return result as List<WorkspaceFileSetWithCustomData<D>>
  }

  override fun getFileInfo(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
  ): WorkspaceFileInternalInfo {
    val unwrappedFile = BackedVirtualFile.getOriginFileIfBacked((file as? VirtualFileWindow)?.delegate ?: file)
    return getMainIndexData().getFileInfo(
      unwrappedFile, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
  }

  override fun <E : WorkspaceEntity> findContainingEntities(
    file: VirtualFile,
    entityClass: Class<E>,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
  ): Collection<E> {
    val allEntities = findContainingEntities(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
    @Suppress("UNCHECKED_CAST")
    return allEntities.filter { entity -> entity.getEntityInterface() == entityClass } as Collection<E>
  }

  override fun findContainingEntities(
    file: VirtualFile,
    honorExclusion: Boolean,
    includeContentSets: Boolean,
    includeContentNonIndexableSets: Boolean,
    includeExternalSets: Boolean,
    includeExternalSourceSets: Boolean,
    includeExternalNonIndexableSets: Boolean,
    includeCustomKindSets: Boolean,
  ): Collection<WorkspaceEntity> {
    val info = getFileInfo(
      file, honorExclusion, includeContentSets, includeContentNonIndexableSets, includeExternalSets, includeExternalSourceSets,
      includeExternalNonIndexableSets, includeCustomKindSets
    )
    return when (info) {
      is WorkspaceFileSetImpl -> listOfNotNull(resolveEntity(info))
      is MultipleWorkspaceFileSets -> info.fileSets.mapNotNull { fileSet ->
        (fileSet as? StoredFileSet?)?.let { resolveEntity(it) }
      }
      is NonWorkspace -> emptyList()
    }
  }

  private fun resolveEntity(fileSet: StoredFileSet): WorkspaceEntity? {
    if (fileSet.entityStorageKind != EntityStorageKind.MAIN) return null
    return fileSet.entityPointer.resolve(WorkspaceModel.getInstance(project).currentSnapshot)
  }

  @RequiresReadLock
  override fun visitFileSets(visitor: WorkspaceFileSetVisitor) {
    getMainIndexData().visitFileSets(visitor)
  }

  override fun getPackageName(fileOrDir: VirtualFile): String? = getMainIndexData().getPackageName(fileOrDir)

  override fun getDirectoriesByPackageName(packageName: String, includeLibrarySources: Boolean): Query<VirtualFile> =
    getMainIndexData().getDirectoriesByPackageName(packageName, includeLibrarySources)

  override fun getDirectoriesByPackageName(packageName: String, scope: GlobalSearchScope): Query<VirtualFile> =
    getDirectoriesByPackageName(packageName, true).filtering { scope.contains(it) }

  override fun getFilesByPackageName(packageName: String): Query<VirtualFile> = getMainIndexData().getFilesByPackageName(packageName)

  private fun getMainIndexData(): WorkspaceFileIndexData {
    val indexData = indexData
    when (indexData) {
      EmptyWorkspaceFileIndexData.NOT_INITIALIZED -> {
        if (project.isDefault) {
          throttledLogger.warn("WorkspaceFileIndex must not be queried for the default project", Throwable())
        }
        else {
          thisLogger().error(
            "WorkspaceFileIndex is not initialized yet, empty data is returned. " +
            "Activities which use the project configuration must be postponed until the project is fully loaded." +
            "It is possible to check Project.isInitialized to verify that the project is fully loaded."
          )
        }
      }
      EmptyWorkspaceFileIndexData.RESET -> {
        return doInitializeBlocking().also { this.indexData = it }
      }
    }
    return indexData
  }

  override fun reset() {
    indexData = EmptyWorkspaceFileIndexData.RESET
  }
}
